#include <stdio.h>
#define COMEÇA 0
#define SIM 1
#define NAO 2

typedef struct {
	char nome[50];
	float porc;
	float desc;
} desconto;


float inicio(){

	float sal;
	printf("\n\tPrograma para calcular desconto no salário.\n");
	printf("\nINSS.\nImposto de renda.\nOutro desconto.\n");

	printf("\n\nPor favor digite seu salário bruto: \n");
	scanf("%f",&sal);
	return sal;
}

desconto cal_imp( float salario){
	
	desconto por_descImp;

		if (salario <=1903.95){
				
				por_descImp.porc = 0;
				
				return por_descImp;	
		
		} else if (salario >1903.95 && salario <= 2826.65 )
			{
				por_descImp.porc= 7.5;
				por_descImp.desc = (salario *7.5)/100;
			
				return por_descImp;	
			}else if (salario > 2826.65 && salario  <= 3751.05)
				{
					por_descImp.porc= 15;
					por_descImp.desc = (salario*15)/100;
					
					return por_descImp;	
			
				}else if(salario >3751.05)
					por_descImp.porc= 27;	
					por_descImp.desc = (salario*27)/100;
						
			return por_descImp;	
}

desconto cal_inss( float salario){
	desconto por_inss;

	if (salario<=1100.00)
	{
		por_inss.porc = 7.5; 
		por_inss.desc = (salario *7.5)/100;
				
		return por_inss;
	} else if ( salario > 1100.00 && salario <=2203.48 )
					{
						por_inss.porc = 9; 
						por_inss.desc = (salario *9)/100;
						return por_inss;
	} else if (salario >2203.48 && salario <= 3305.22 )
				{
						por_inss.porc = 12; 
						por_inss.desc = (salario*12)/100;
						return por_inss;
	}	else if(salario >3305.22)
					por_inss.porc = 14; 
					por_inss.desc = (salario*14)/100;
					
					return por_inss;
}


desconto cal_Outro(float sal){
	desconto  out;
	int op_esc;

	op_esc = COMEÇA;

	while (op_esc != NAO)
	{

		printf("\nDeseja acrescentar um novo desconto?\n1-SIM\n2-NÃO\n");
		scanf("%d",&op_esc);

		if (op_esc == SIM)
		{
			printf("\nDigite o nome do desconto:\n");
		 	scanf("%s",out.nome);
		 
		 	printf("\nDigite a porcentagem que é descontado:\n");
		 	scanf("%f",&out.porc);
		 
		
		 	out.desc = (sal*out.porc)/100;

			 return out;

		}else if(op_esc == NAO)
					{
						out.desc = 0;
						printf("\nOpção de acrescentar desconto não solicitada.\n");
						return out;
					}else if ( op_esc != SIM && op_esc)
								{
									printf("\n\t---Opção Invalida.Por favor verificar opções!!---\n\n");
								}
	}
}

void resultado(float  salB,desconto impo,desconto ss, desconto novo){

	 float desc_T,sal_liqui;
	 
		printf("\n\tResultado dos descontos:\n");

	if(impo.porc == 0){
    		printf("\nDesconto do Imposto de Renda: Isento. \n\n");
			} else{
					printf("\nImposto de Renda:\nPorcentagem: %.2f\nDesconto Anual: R$ %.2f\n\n",impo.porc,impo.desc);
			}
	
	printf("\nINSS:\nPorcentagem: %.2f\nDesconto: R$ %.2f\n\n\n",ss.porc,ss.desc);
	if (novo.desc == 0){
					 printf("\nOutro desconto:\nOpção não solicitada!!\n");
			}else {
					printf("\nOutro Desconto: %s\nPorcentagem: %.2f\nDesconto: %.2f\n\n",novo.nome,novo.porc,novo.desc);
			}
	desc_T = ss.desc + novo.desc;
	printf("\n\nTotal dos descontos:\n%.2f\n\n",desc_T);
	sal_liqui = salB - desc_T;
	printf("\nSeu salário liquido é : \n%.2f\n",sal_liqui);

}