#include "funcoesg.h"


int main(void) {
	float salario;
	desconto novo_desc,imposto,inss;
	int novamente;

	novamente = COMEÇA;

	do {
	
	salario = inicio();
	imposto = cal_imp (salario);
	inss = cal_inss (salario);
	novo_desc = cal_Outro(salario);
	resultado(salario,imposto, inss,novo_desc);

	printf("\n\nDeseja fazer outro calculo de desconto ?\n1-Sim\n2-Não\n");
	scanf("%d",&novamente);


	if ( novamente == NAO){
			printf("\n<<<<<Fim do Programa!!>>>\n");
	}else  if (novamente != SIM && novamente != NAO )
		printf("\n\t---Opção Invalida.Por favor verificar opções!!---\n\n");

	

	}while(novamente != NAO);
	




}