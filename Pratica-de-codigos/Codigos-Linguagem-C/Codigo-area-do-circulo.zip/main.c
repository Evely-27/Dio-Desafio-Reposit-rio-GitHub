#include <stdio.h> 

int main ( void ) {

    double área, raio,pi ;
    pi=3.14159 ;

  printf("EScreva o raio do círculo: \n");
  scanf("\n%lf",&raio);

  área = pi*(raio*raio) ;

  printf("A área do cŕculo é : %lf \n",área);

  
  return 0 ;

}