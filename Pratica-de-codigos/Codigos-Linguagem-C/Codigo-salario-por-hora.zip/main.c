#include <stdio.h>

int main(void) {
  float hora, ganho,salário;

  printf("Digite quantas horas trabalha por mês:\n");
  scanf("\n%f", &hora);

  printf("Digite quanto recebe por horas trabalhadas: \n");
  scanf("\n%f", &ganho);

  salário = hora*ganho;
  
  printf("Seu salário bruto no mês é: %.f\n", salário);

  return 0;
}