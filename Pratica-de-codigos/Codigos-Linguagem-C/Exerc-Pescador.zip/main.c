#include <stdio.h>

int main(void) {
  float peso, excesso, multa ;

  printf("Digite o peso do peixe:");
  scanf("%f",&peso);

   excesso =  peso-50 ;
   scanf("%f",&excesso);

  printf (" O excesso foi de: %f",excesso);
  
   multa = excesso * 4;
   scanf("%f",&multa);

  printf("\n A multa é de: %f",multa);

}
