#include <stdio.h>
#include <math.h>

int main(void) {
 double área,preço,litro,lata;

  printf("Digite a área a ser pintanda em metros quadrados: \n");
  scanf(" %lf", &área);
  
    if (área <=54 && área >= 6)
    printf("Uma lata,de 18L será o suficiente,e custará R$80.0");

     else if (área> 54){
     lata=ceil(área/ 54);
     preço= lata * 80;
     printf("A quantidade de lata com 18L será %.lf e o preço fica R$ %.lf",lata,preço);

     }
  

}