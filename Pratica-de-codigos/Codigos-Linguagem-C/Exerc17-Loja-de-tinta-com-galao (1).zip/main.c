#include <stdio.h>
#include <math.h>
#include <stdlib.h>

int main (void){
  double A,GL,lata,preço;
  int es;

  printf("Digite a área a ser pintada em metros quadrados: \nOBS:Só vendemos a partir de 21.6 metros quadrados.");
  scanf(" %lf", &A);
  printf("Por favor escolher um tipo de compra.\n");
  printf(" 1- compra só com lata de 18L.\n 2- compra só com galão de 3,6L.\n 3- compra com lata e galões.\n");
  scanf(" %d",&es);

    switch (es){
      case 1:
      lata = ceil ( A / 54);
      preço = lata * 80;
      printf("Sua compra sai com %.lf latas e o preço por R$ %.lf .",lata,preço);
      break;

      case 2 : 
      GL = ceil (A / 21.6);
      preço = GL * 25;
      printf("Sua compra sai com %.lf galões e o preço por R$%.lf.",GL,preço);
      break;

      case 3 :




    default:
      printf("escolha algo.");
    }






}